package com.ssafy.ws_android_jetpack_01_3_kimjihun

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.ssafy.ws_android_jetpack_01_3_kimjihun.database.Photo
import com.ssafy.ws_android_jetpack_01_3_kimjihun.databinding.ListItemGalleryBinding

class GalleryAdapter(var context: Context,var datas : MutableList<Photo>) : RecyclerView.Adapter<GalleryAdapter.ViewHolder>(){
    inner class ViewHolder(private val binding: ListItemGalleryBinding) : RecyclerView.ViewHolder(binding.root){

        fun bind(item : Photo){
            binding.apply {
                activity = context as MainActivity
                photoDto = item
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            DataBindingUtil.inflate(LayoutInflater.from(parent.context),R.layout.list_item_gallery,parent,false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dto = datas[position]
        holder.apply {
            bind(dto)
            itemView.tag = dto
        }
    }

    override fun getItemCount() = datas.size


}