package com.ssafy.ws_android_jetpack_01_3_kimjihun.repository

import android.content.Context
import androidx.room.Room
import androidx.room.withTransaction
import com.ssafy.ws_android_jetpack_01_3_kimjihun.database.Photo
import com.ssafy.ws_android_jetpack_01_3_kimjihun.database.PhotoDatabase

private const val TAG = "PhotoRepository_싸피"
private const val DATABASE_NAME = "photo-database.db"
class PhotoRepository private constructor(context : Context){
    private val database : PhotoDatabase = Room.databaseBuilder(
        context.applicationContext,
        PhotoDatabase::class.java,
        DATABASE_NAME
    ).build()

    private val photoDao = database.photoDao()

    suspend fun getPhotos() : MutableList<Photo>{
        return photoDao.getPhotos()
    }

    suspend fun getPhoto(id : Long) : Photo{
        return photoDao.getPhoto(id)
    }

    suspend fun insertPhoto(photo:Photo) = database.withTransaction {
        photoDao.insertNote(photo)
    }

    companion object{
        private var INSTANCE : PhotoRepository? = null

        fun initialize(context : Context){
            if(INSTANCE ==null){
                INSTANCE = PhotoRepository(context)
            }
        }
        fun get() : PhotoRepository{
            return INSTANCE?:throw IllegalStateException("PhotoRepository must be initialized")
        }
    }

}