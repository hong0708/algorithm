package com.ssafy.ws_android_jetpack_01_3_kimjihun

import androidx.lifecycle.ViewModel
import com.ssafy.ws_android_jetpack_01_3_kimjihun.database.Photo
import com.ssafy.ws_android_jetpack_01_3_kimjihun.repository.PhotoRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PhotoViewModel : ViewModel() {
    var photos = mutableListOf<Photo>()
        private set
    var photo = Photo("",0,"")
        private set

    fun setPhotos(p : MutableList<Photo>){
        photos = p
    }
    fun setPhoto(p : Photo){
        photo = p
    }

}