package com.ssafy.ws_android_jetpack_01_3_kimjihun.database

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Photo::class] , version = 1)
abstract class PhotoDatabase : RoomDatabase() {

    abstract fun photoDao() : PhotoDao

}