package com.ssafy.ws_android_jetpack_01_3_kimjihun.util

import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.databinding.BindingAdapter


@BindingAdapter("imageDrawable")
fun bindImageFromRes(view: ImageView, src:String) {
    view.setBackgroundResource(view.resources.getIdentifier(src.split("/")[1],"drawable",view.context.packageName))
    //img.setBackgroundResource(itemView.resources.getIdentifier("@drawable/gonjo".split("/")[1],"drawable",itemView.context.packageName))
}