package com.ssafy.ws_android_jetpack_01_3_kimjihun.util

import android.app.Application
import com.ssafy.ws_android_jetpack_01_3_kimjihun.repository.PhotoRepository

class PhotoApplicationClass : Application(){

    override fun onCreate() {
        super.onCreate()
        PhotoRepository.initialize(this)
    }

}