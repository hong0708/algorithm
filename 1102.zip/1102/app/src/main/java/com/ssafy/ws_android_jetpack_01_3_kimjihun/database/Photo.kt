package com.ssafy.ws_android_jetpack_01_3_kimjihun.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

private const val TAG = "Photo_싸피"
@Entity(tableName = "photo")
class Photo(
    var location: String,
    var date: Long,
    var src: String
) {
    @PrimaryKey(autoGenerate = true)
    var ID: Long = 0

    constructor(id : Long , location: String , date: Long , src: String) : this(location, date, src)

    override fun toString(): String {
        return "Photo(location='$location', date=$date, src='$src', ID=$ID)"
    }

    /*fun onClickListener(view: View) {
        Log.d(TAG, "onClickListener: ")
    }*/


}