package com.ssafy.ws_android_jetpack_01_3_kimjihun

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.ViewModelProvider
import com.ssafy.ws_android_jetpack_01_3_kimjihun.database.Photo
import com.ssafy.ws_android_jetpack_01_3_kimjihun.repository.PhotoRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime

private const val TAG = "MainActivity_싸피"
class MainActivity : AppCompatActivity() {
    private lateinit var photoRepository: PhotoRepository
    private lateinit var viewModel:PhotoViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        viewModel = ViewModelProvider(this)[PhotoViewModel::class.java]
        photoRepository = PhotoRepository.get()
        addPhoto()
        CoroutineScope(Dispatchers.IO).launch {
            viewModel.setPhotos(getData())
            changeFragToGallery()
        }
    }

    fun changeFragToGallery(){
        supportFragmentManager.beginTransaction()
            .replace(R.id.main_frag,GalleryFragment()).commit()
    }

    private suspend fun getData():MutableList<Photo>{
        return photoRepository.getPhotos()
    }
    interface onBackPressedListener{
        fun onBackPressed()
    }

    override fun onBackPressed() {
        val fragmentList = supportFragmentManager.fragments.forEach {
            if(it is onBackPressedListener){
                (it as onBackPressedListener).onBackPressed()
                return
            }
        }

    }

    fun onClick(p: Photo){
        viewModel.setPhoto(p)
        supportFragmentManager.beginTransaction()
            .replace(R.id.main_frag,PhotoFragment()).commit()
    }

    private fun addPhoto(){
        CoroutineScope(Dispatchers.IO).launch {
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/apple"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/beach"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/bigben"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/bird"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/blueberries"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/city"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/cornflower"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/cute"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/dubai"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/duckling"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/fantasy"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/jellyfish"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/milkyway"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/mountain"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/mountains"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/nature"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/nuthatch"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/papenburg"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/rhododendron"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/sea"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/sky"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/thunderstorm"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/tree"))
            photoRepository.insertPhoto(Photo("구미시 공단동", System.currentTimeMillis(),"@drawable/woman"))
        }
    }





}