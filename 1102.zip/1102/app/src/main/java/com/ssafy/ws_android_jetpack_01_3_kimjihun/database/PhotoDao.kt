package com.ssafy.ws_android_jetpack_01_3_kimjihun.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy.REPLACE
import androidx.room.Query

@Dao
interface PhotoDao {

    @Query("SELECT * FROM photo")
    suspend fun getPhotos() : MutableList<Photo>

    @Query("SELECT * FROM photo WHERE id=(:id)")
    suspend fun getPhoto(id:Long) : Photo

    @Insert(onConflict = REPLACE)
    suspend fun insertNote(photo : Photo)


}